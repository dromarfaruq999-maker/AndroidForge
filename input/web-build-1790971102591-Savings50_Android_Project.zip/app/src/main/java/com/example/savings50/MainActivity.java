package com.example.savings50;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    static final int N=50, AMOUNT=600;
    SharedPreferences prefs;
    GridLayout grid; TextView saved,left,done; ProgressBar progress;

    String bn(int n){
        return String.valueOf(n).replace("0","০").replace("1","১").replace("2","২")
        .replace("3","৩").replace("4","৪").replace("5","৫").replace("6","৬")
        .replace("7","৭").replace("8","৮").replace("9","৯");
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs=getSharedPreferences("saving_data",MODE_PRIVATE);
        grid=findViewById(R.id.grid);
        saved=findViewById(R.id.savedText);
        left=findViewById(R.id.leftText);
        done=findViewById(R.id.doneText);
        progress=findViewById(R.id.progress);

        findViewById(R.id.allButton).setOnClickListener(v->{
            SharedPreferences.Editor e=prefs.edit();
            for(int i=0;i<N;i++) e.putBoolean("box"+i,true);
            e.apply(); render();
        });

        findViewById(R.id.resetButton).setOnClickListener(v->
            new AlertDialog.Builder(this)
            .setTitle("সব টিক মুছবেন?")
            .setNegativeButton("না",null)
            .setPositiveButton("হ্যাঁ",(d,w)->{prefs.edit().clear().apply();render();})
            .show());

        render();
    }

    void render(){
        grid.removeAllViews();
        int gap=6;
        for(int i=0;i<N;i++){
            final int x=i;
            boolean checked=prefs.getBoolean("box"+i,false);
            TextView t=new TextView(this);
            t.setText(bn(i+1)+"\n"+(checked?"✓\n":"")+"৬০০ টাকা");
            t.setTextSize(13);
            t.setGravity(Gravity.CENTER);
            t.setTextColor(Color.DKGRAY);
            GradientDrawable bg=new GradientDrawable();
            bg.setCornerRadius(24);
            bg.setStroke(2,Color.parseColor(checked?"#16A34A":"#D7DEE7"));
            bg.setColor(Color.parseColor(checked?"#DCFCE7":"#FFFFFF"));
            t.setBackground(bg);

            GridLayout.LayoutParams lp=new GridLayout.LayoutParams();
            lp.width=0; lp.height=0;
            lp.columnSpec=GridLayout.spec(i%5,1f);
            lp.rowSpec=GridLayout.spec(i/5,1f);
            lp.setMargins(gap,gap,gap,gap);
            grid.addView(t,lp);

            t.setOnClickListener(v->{
                prefs.edit().putBoolean("box"+x,!prefs.getBoolean("box"+x,false)).apply();
                render();
            });
        }

        int c=0;
        for(int i=0;i<N;i++) if(prefs.getBoolean("box"+i,false)) c++;
        saved.setText("জমা হয়েছে: "+bn(c*AMOUNT)+" টাকা");
        left.setText("বাকি: "+bn((N-c)*AMOUNT)+" টাকা");
        done.setText("সম্পন্ন: "+bn(c)+" / "+bn(N));
        progress.setProgress(c);
    }
}
